package activity

import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.samyak.bookgram.R
import com.squareup.picasso.Picasso
import database.BookDatabase
import database.BookEntity
import org.json.JSONObject
import util.ConnectionManager
import java.lang.Exception
import androidx.appcompat.widget.Toolbar

class DescriptionActivity : AppCompatActivity() {
    lateinit var descriptionLayout:RelativeLayout
    lateinit var desLinear:LinearLayout
    lateinit var desBookImage:ImageView
    lateinit var desBookName:TextView
    lateinit var desBookAuthor:TextView
    lateinit var desBookPrice:TextView
    lateinit var desRating:TextView
    lateinit var desRelative:RelativeLayout
    lateinit var aboutTheBook:TextView
    lateinit var desButton:Button
    lateinit var desProgressBar: ProgressBar
    lateinit var progressLayout:RelativeLayout
    lateinit var desToolbar: Toolbar

    var id:String?="100"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)


        descriptionLayout=findViewById(R.id.descriptionLayout)
        desLinear=findViewById(R.id.desLinear)
        desBookImage=findViewById(R.id.desBookImage)
        desBookName=findViewById(R.id.desBookName)
        desBookAuthor=findViewById(R.id.desBookAuthor)
        desBookPrice=findViewById(R.id.desBookPrice)
        desRating=findViewById(R.id.desRating)
        desRelative=findViewById(R.id.desRelative)
        aboutTheBook=findViewById(R.id.aboutTheBook)
        desButton=findViewById(R.id.desButton)
        desProgressBar=findViewById(R.id.desProgressBar)
        progressLayout=findViewById(R.id.progressLayout)
        progressLayout.visibility=View.VISIBLE
        desToolbar=findViewById(R.id.desToolbar)


        if (intent!=null){
            id=intent.getStringExtra("book_id")
        }
        else{
            Toast.makeText(this@DescriptionActivity,"Error 1",Toast.LENGTH_SHORT).show()
        }

        val queue=Volley.newRequestQueue(this@DescriptionActivity)
        val url="http://13.235.250.119/v1/book/get_book/"
        val jsonParams=JSONObject()
        jsonParams.put("book_id",id)

        if (ConnectionManager().checkConnectivity(this)) {
            val jsonRequest =
                object : JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {

                    try {
                        val success = it.getBoolean("success")
                        if (success) {
                            val jsonObject = it.getJSONObject("book_data")
                            progressLayout.visibility = View.GONE

                            val bookImageUrl=jsonObject.getString("image")
                            Picasso.get().load(jsonObject.getString("image"))
                                .error(R.drawable.bookhub)
                                .into(desBookImage)
                            desBookName.text = jsonObject.getString("name")
                            desBookAuthor.text = jsonObject.getString("author")
                            desBookPrice.text = jsonObject.getString("price")
                            desRating.text = jsonObject.getString("rating")
                            aboutTheBook.text = jsonObject.getString("description")



                            val bookEntity=BookEntity(
                                id?.toInt() as Int,
                                desBookName.text.toString(),
                                desBookAuthor.text.toString(),
                                desBookPrice.text.toString(),
                                desRating.text.toString(),
                                aboutTheBook.text.toString(),
                                bookImageUrl
                            )
                            val checkFav=DBAsyncTask(applicationContext,bookEntity,1).execute()
                            val isFav=checkFav.get()
                            if (isFav){
                                desButton.text="Remove from Favourites"
                            }
                            else{
                                desButton.text="Add to Favourites"
                            }
                            desButton.setOnClickListener {
                                if (!DBAsyncTask(applicationContext, bookEntity, 1).execute().get()){
                                    val async=DBAsyncTask(applicationContext,bookEntity,2).execute()
                                    val result=async.get()
                                    if (result){
                                        Toast.makeText(this@DescriptionActivity,"Book added to Favourites",Toast.LENGTH_SHORT).show()
                                        desButton.text="Remove from Favourites"
                                    }
                                    else{
                                        Toast.makeText(this@DescriptionActivity,"Error 2",Toast.LENGTH_SHORT).show()
                                    }
                                } else{
                                    val async=DBAsyncTask(applicationContext,bookEntity,3).execute()
                                    val result=async.get()
                                    if (result){
                                        Toast.makeText(this@DescriptionActivity,"Book removed from Favourites",Toast.LENGTH_SHORT).show()
                                        desButton.text="Add to Favourites"
                                    }
                                    else{
                                        Toast.makeText(this@DescriptionActivity,"Error 3",Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }




                        } else {
                            Toast.makeText(
                                this@DescriptionActivity,
                                "Error 4",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: Exception) {
                    }

                }, Response.ErrorListener {
                    "Error is $it"
                }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["content-type"]="application/json"
                        headers["token"]="38dfe39b21c6c5"
                        return headers

                    }
                }
            queue.add(jsonRequest)
        }
        setUpToolbar()
    }
    fun setUpToolbar(){
        setSupportActionBar(desToolbar)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
    class DBAsyncTask(val context: Context,val bookEntity: BookEntity,val mode:Int):AsyncTask<Void,Void,Boolean>() {
        val db= Room.databaseBuilder(context,BookDatabase::class.java,"books-db").build()

        override fun doInBackground(vararg params: Void?): Boolean {

            when(mode){

                1->{
                    // Check if the Book is already add
                    val book:BookEntity?=db.bookDao().getBookById(bookEntity.book_id.toString())
                    db.close()
                    return book!=null
                }
                2->{
                    //Save the Book
                    db.bookDao().insertBook(bookEntity)
                    db.close()
                    return true
                }
                3->{
                    db.bookDao().deleteBook(bookEntity)
                    db.close()
                    return true
                }

            }

            return false
        }
    }
}
