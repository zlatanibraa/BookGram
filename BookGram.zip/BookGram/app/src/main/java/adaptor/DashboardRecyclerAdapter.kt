package adaptor

import activity.DescriptionActivity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.samyak.bookgram.R
import com.squareup.picasso.Picasso
import fragment.DashboardFragment
import model.Book


class DashboardRecyclerAdapter(val context:Context,val itemList:ArrayList<Book>):RecyclerView.Adapter<DashboardRecyclerAdapter.DashboardViewHolder>() {

    class DashboardViewHolder(view:View):RecyclerView.ViewHolder(view){
        val imgBookImage:ImageView=view.findViewById(R.id.imgBookImage)
        val txtRating:TextView=view.findViewById(R.id.txtRating)
        val txtAuthorName:TextView=view.findViewById(R.id.txtBookAuthor)
        val txtBookName:TextView=view.findViewById(R.id.txtBookName)
        val txtBookPrice:TextView=view.findViewById(R.id.txtBookPrice)
        val linearDashboard:LinearLayout=view.findViewById(R.id.linearDashboard)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.dashboard_single_row,
                parent,false)
        return DashboardViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        val book=itemList[position]
        Picasso.get().load(book.imgBookImage).error(R.drawable.bookhub).into(holder.imgBookImage)
        holder.txtAuthorName.text=book.txtBookAuthor
        holder.txtBookName.text=book.txtBookName
        holder.txtBookPrice.text=book.txtBookPrice
        holder.txtRating.text=book.txtBookRating

        holder.linearDashboard.setOnClickListener {
            val intent=Intent(context,DescriptionActivity::class.java)
            intent.putExtra("book_id",book.id)
            context.startActivity(intent)
        }

    }
}