package fragment

import adaptor.DashboardRecyclerAdapter
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.samyak.bookgram.R
import model.Book

class DashboardFragment : Fragment() {
    lateinit var recyclerView: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager
    val bookInfoList= arrayListOf<Book>()
    lateinit var relativeProgress:RelativeLayout
    lateinit var progressBar:ProgressBar
    lateinit var recyclerAdapter:DashboardRecyclerAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        relativeProgress=view.findViewById(R.id.relativeProgress)
        progressBar=view.findViewById(R.id.progressBar)

        recyclerView = view.findViewById(R.id.recyclerView)
        layoutManager = LinearLayoutManager(activity)

        relativeProgress.visibility=View.VISIBLE


    val queue=Volley.newRequestQueue(activity as Context)
        val url="http://13.235.250.119/v1/book/fetch_books"
        val jsonObjectRequest=object :JsonObjectRequest(Request.Method.GET,url,null, Response.Listener {
                relativeProgress.visibility = View.GONE
            val success = it.getBoolean("success")
            if (success) {
                val data = it.getJSONArray("data")
                for (i in 0 until data.length()) {
                    val bookJsonObject = data.getJSONObject(i)
                    val bookObject = Book(
                        bookJsonObject.getString("book_id"),
                        bookJsonObject.getString("name"),
                        bookJsonObject.getString("author"),
                        bookJsonObject.getString("rating"),
                        bookJsonObject.getString("price"),
                        bookJsonObject.getString("image")
                    )
                    bookInfoList.add(bookObject)
                    recyclerAdapter = DashboardRecyclerAdapter(activity as Context, bookInfoList)
                    recyclerView.adapter = recyclerAdapter
                    recyclerView.layoutManager = layoutManager

                }
            } else {
                Toast.makeText(context, "Error Occurred", Toast.LENGTH_SHORT).show()
            }

        },
            Response.ErrorListener {
                "Error is $it"}){
            override fun getHeaders(): MutableMap<String, String> {

                val headers=HashMap<String,String>()
                headers["content-type"]="application/json"
                headers["token"]="38dfe39b21c6c5"
                return headers
            }
        }
        queue.add(jsonObjectRequest)
        return view
    }

}
