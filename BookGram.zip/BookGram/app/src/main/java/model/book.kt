package model


data class Book (val id:String,
                 val txtBookName:String,
                 val txtBookAuthor:String,
                 val txtBookRating:String,
                 val txtBookPrice:String,
                 val imgBookImage:String) {
}